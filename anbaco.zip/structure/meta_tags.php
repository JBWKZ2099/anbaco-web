<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta charset="UTF-8">
<!--Font Awesome-->
<link href="assets/css/font-awesome.css" rel="stylesheet" />

<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
<script type="text/javascript" src="assets/js/bootstrap.js"></script>
<script type="text/javascript" src="assets/js/jquery-2.1.4.js"></script>

<!--Own Style-->
<link rel="stylesheet" type="text/css" href="assets/css/style.css">
<!--Own Script-->
<script type="text/javascript" src="assets/js/script.js"></script>