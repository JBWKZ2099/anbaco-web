<!-- REQUIRED SCRIPTS FILES -->
<!-- CORE JQUERY FILE -->
<script src="assets/js/jquery-2.1.4.js"></script>
<!-- REQUIRED BOOTSTRAP SCRIPTS -->
<script src="assets/js/bootstrap.js"></script>